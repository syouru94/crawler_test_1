from distutils.core import setup
setup(
    name = 'First Project',
    packages = ['package1', 'package2' ] ,
    version = 'v0.2',
    description = '專案試做',
    author = 'syouru94',
    author_email = 'xero120017@gmail.com',
    url = 'https://github.com/syouru94/pip_project_1',
    download_url = 'https://github.com/syouru94/pip_project_1/archive/v0.1.zip',
    keywords = ['test'],
    classifiers = []
)
